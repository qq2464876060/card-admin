
<template>
  <div class="p-4">
    <h2 class="text-xl">欢迎进入后台首页</h2>
  </div>
</template>
