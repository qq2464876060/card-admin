
<template>
  <router-view />
</template>
